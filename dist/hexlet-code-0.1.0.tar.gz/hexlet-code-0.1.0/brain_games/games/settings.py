# Welcome text for games
brain_even = 'Answer "yes" if the number is even, otherwise answer "no".'
brain_calc = 'What is the result of the expression?'
brain_gcd = 'Find the greatest common divisor of given numbers.'

no_game = 'I don\'t know how and what you run, but this ga,e is NONE?'

# hom many games(without lose) you need to win for complite the chellenge.
games_ctn = 3
