#!/usr/bin/env python
from brain_games.core import core


def main():
    core('brain_prime')


if __name__ == '__main__':
    main()
